

class DigitalBonus:
    def __init__(self,
                 serial: str,
                 secret: str
                 ):
        self.serial = serial
        self.secret = secret
